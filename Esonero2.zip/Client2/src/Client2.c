/*
 ============================================================================
 Name        : Client2.c
 Author      : Guillaume Desaphy
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif
#include <stdio.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

int main(void) {
#if defined WIN32
	//Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup().\n");
		return 0;
	}
#endif
	struct hostent *host = gethostbyname(NAME_IP);
	if (host == NULL) {
		printf("Error getting host.\n");
		clearwinsock();
		return -1;
	}
	printf("Server name: %s (IP: %s, port: %d)\n", NAME_IP, inet_ntoa(*(struct in_addr *)host->h_addr), PROTO_PORT);

	int my_socket;
	struct sockaddr_in server_address;
	unsigned int server_address_size = sizeof(server_address);
	int rcv_msg_size;

	//socket creation
	if ((my_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		printf("Error creating socket.\n");
		clearwinsock();
		return -1;
	}

	//set the server address
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(PROTO_PORT);
	server_address.sin_addr = *((struct in_addr *)host->h_addr);

	printf("Enter the command for type and length of password you want to generate(enter 'h' to help or 'q' to end): ");
	char command[64];
	scanf("%s", command);
	char type = command[0];       //first char is the type of password
	int length = atoi(&command[1]); //convert next chars in an integer for length
	while(type != 'q') {
		while ((type!='n' && type!='a' && type!='m' && type!='s' && type!='u') || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
			if (type=='h' && length==0) {
				printf("Password Generator Help Menu\nCommands:\n");
				printf("h        : show this help menu\n"
						"n LENGTH : generate numeric password (digits only)\n"
						"a LENGTH : generate alphabetic password (lowercase letters)\n"
						"m LENGTH : generate mixed password (lowercase letters and numbers)\n"
						"s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n"
						"u LENGTH : generate unambiguous secure password (no similar-looking characters)\n"
						"q        : quit application\n");
				printf("LENGTH must be between 6 and 32 characters\nAmbiguous characters excluded in 'u' option:\n");
				printf("0 O o (zero and letters O)\n1 l I i (one and letters l, I)\n2 Z z (two and letter Z)\n5 S s (five and letter S)\n8 B (eight and letter B)\n\n");
				printf("Enter another command: \n");
			}
			else if (type == 'q') {
				printf("Char 'q' entered, connection closed.\n");
				closesocket(my_socket);
				clearwinsock();
				return 0;
			}
			else {
				printf("Error: Invalid type or length. Enter another command: \n");
			}
			scanf("%s", command);
			type = command[0];
			length = atoi(&command[1]);
		}

		//send the command to server
		printf("Sending command %s...\n", command);
		if (sendto(my_socket, command, strlen(command), 0, (struct sockaddr *)&server_address, sizeof(server_address)) != strlen(command)) {
			printf("Error sending command.\n");
			closesocket(my_socket);
			clearwinsock();
			return -1;
		}
		printf("Command sent.\n");

		//receive the password from server
		char password[64];
		memset(password, 0, sizeof(password)); //reset password
		printf("Receiving password from server...\n");
		if ((rcv_msg_size = recvfrom(my_socket, password, BUFFMAX, 0, (struct sockaddr *)&server_address, &server_address_size)) < 0) {
			printf("Error receiving data");
			closesocket(my_socket);
			clearwinsock();
			return -1;
		}
		printf("Password generated from server: %s.\n", password);
		printf("Enter the command for type and length of password you want to generate(enter 'h' to help or 'q' to end): ");
		scanf("%s", command);
		type = command[0];
		length = atoi(&command[1]);
	}

	printf("Char 'q' entered, connection closed.\n");
	closesocket(my_socket);
	clearwinsock();
	return 0;

}
